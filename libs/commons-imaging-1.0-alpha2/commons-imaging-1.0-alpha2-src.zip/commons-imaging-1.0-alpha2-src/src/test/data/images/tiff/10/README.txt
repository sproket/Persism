Imaging247 is a copy of the file neutre.TIFF that was supplied by the user for JIRA 247. 

Imaging258 is a test file in which an offset field is given as type IFD rather
than type Long.
 