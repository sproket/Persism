package net.sf.persism.dao;

/**
 * Created with IntelliJ IDEA.
 * User: danhoward
 * Date: 12-05-14
 * Time: 6:27 AM
 */
public enum Regions {
    North, South, East, West;
}
