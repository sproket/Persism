BUILT WITH JAVA 5
Welcome to Persism
==================

Persism is a wood simple, no-nonsense, auto-configuration, convention over configuration ORM library for Java.

Thanks for your interest!
Contact sproket AT videotron DOT ca


Release 0.9.3

Known issues
------------
* Stored procedures used as queries not fully tested yet
